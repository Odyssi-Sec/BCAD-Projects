﻿namespace PROG6212.POE.ST10153536
{
    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
    }
}
